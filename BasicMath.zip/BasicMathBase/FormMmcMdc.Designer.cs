﻿
namespace BasicMathBase
{
    partial class FormMmcMdc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitleMmcMdc = new System.Windows.Forms.Label();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.txtboxAnwserMdc = new System.Windows.Forms.TextBox();
            this.lblAnwserMdc = new System.Windows.Forms.Label();
            this.txtboxAnwserMmc = new System.Windows.Forms.TextBox();
            this.lblAnwserMmc = new System.Windows.Forms.Label();
            this.btnCorrectMdc = new System.Windows.Forms.Button();
            this.btnCorrectMmc = new System.Windows.Forms.Button();
            this.btnClearMdc = new System.Windows.Forms.Button();
            this.btnClearMmc = new System.Windows.Forms.Button();
            this.lblb2 = new System.Windows.Forms.Label();
            this.lblb1 = new System.Windows.Forms.Label();
            this.txtboxMdcB = new System.Windows.Forms.TextBox();
            this.txtboxMmcB = new System.Windows.Forms.TextBox();
            this.checkboxMdc = new System.Windows.Forms.CheckBox();
            this.checkboxMmc = new System.Windows.Forms.CheckBox();
            this.lbla2 = new System.Windows.Forms.Label();
            this.lbla1 = new System.Windows.Forms.Label();
            this.txtboxMdcA = new System.Windows.Forms.TextBox();
            this.txtboxMmcA = new System.Windows.Forms.TextBox();
            this.checkboxAlgoritmoEuclides = new System.Windows.Forms.CheckBox();
            this.panelTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitleMmcMdc
            // 
            this.lblTitleMmcMdc.AutoSize = true;
            this.lblTitleMmcMdc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(23)))), ((int)(((byte)(42)))));
            this.lblTitleMmcMdc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitleMmcMdc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(200)))));
            this.lblTitleMmcMdc.Location = new System.Drawing.Point(155, 27);
            this.lblTitleMmcMdc.Name = "lblTitleMmcMdc";
            this.lblTitleMmcMdc.Size = new System.Drawing.Size(659, 37);
            this.lblTitleMmcMdc.TabIndex = 2;
            this.lblTitleMmcMdc.Text = "NATURAL COMO PRODUTO DE PRIMOS";
            // 
            // panelTitle
            // 
            this.panelTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(23)))), ((int)(((byte)(42)))));
            this.panelTitle.Controls.Add(this.lblTitleMmcMdc);
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(0, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(984, 95);
            this.panelTitle.TabIndex = 25;
            // 
            // txtboxAnwserMdc
            // 
            this.txtboxAnwserMdc.Location = new System.Drawing.Point(596, 372);
            this.txtboxAnwserMdc.Name = "txtboxAnwserMdc";
            this.txtboxAnwserMdc.Size = new System.Drawing.Size(115, 31);
            this.txtboxAnwserMdc.TabIndex = 4158;
            // 
            // lblAnwserMdc
            // 
            this.lblAnwserMdc.AutoSize = true;
            this.lblAnwserMdc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAnwserMdc.Location = new System.Drawing.Point(506, 372);
            this.lblAnwserMdc.Name = "lblAnwserMdc";
            this.lblAnwserMdc.Size = new System.Drawing.Size(84, 25);
            this.lblAnwserMdc.TabIndex = 4157;
            this.lblAnwserMdc.Text = "Resposta";
            // 
            // txtboxAnwserMmc
            // 
            this.txtboxAnwserMmc.Location = new System.Drawing.Point(596, 244);
            this.txtboxAnwserMmc.Name = "txtboxAnwserMmc";
            this.txtboxAnwserMmc.Size = new System.Drawing.Size(115, 31);
            this.txtboxAnwserMmc.TabIndex = 4156;
            // 
            // lblAnwserMmc
            // 
            this.lblAnwserMmc.AutoSize = true;
            this.lblAnwserMmc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAnwserMmc.Location = new System.Drawing.Point(506, 244);
            this.lblAnwserMmc.Name = "lblAnwserMmc";
            this.lblAnwserMmc.Size = new System.Drawing.Size(84, 25);
            this.lblAnwserMmc.TabIndex = 4155;
            this.lblAnwserMmc.Text = "Resposta";
            // 
            // btnCorrectMdc
            // 
            this.btnCorrectMdc.FlatAppearance.BorderSize = 2;
            this.btnCorrectMdc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorrectMdc.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCorrectMdc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnCorrectMdc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCorrectMdc.Location = new System.Drawing.Point(740, 345);
            this.btnCorrectMdc.Name = "btnCorrectMdc";
            this.btnCorrectMdc.Size = new System.Drawing.Size(108, 43);
            this.btnCorrectMdc.TabIndex = 4154;
            this.btnCorrectMdc.Text = "Corrigir";
            this.btnCorrectMdc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCorrectMdc.UseVisualStyleBackColor = true;
            this.btnCorrectMdc.Click += new System.EventHandler(this.btnCorrectMdc_Click);
            // 
            // btnCorrectMmc
            // 
            this.btnCorrectMmc.FlatAppearance.BorderSize = 2;
            this.btnCorrectMmc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorrectMmc.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCorrectMmc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnCorrectMmc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCorrectMmc.Location = new System.Drawing.Point(740, 216);
            this.btnCorrectMmc.Name = "btnCorrectMmc";
            this.btnCorrectMmc.Size = new System.Drawing.Size(108, 43);
            this.btnCorrectMmc.TabIndex = 4153;
            this.btnCorrectMmc.Text = "Corrigir";
            this.btnCorrectMmc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCorrectMmc.UseVisualStyleBackColor = true;
            this.btnCorrectMmc.Click += new System.EventHandler(this.btnCorrectMmc_Click);
            // 
            // btnClearMdc
            // 
            this.btnClearMdc.FlatAppearance.BorderSize = 2;
            this.btnClearMdc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearMdc.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClearMdc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnClearMdc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClearMdc.Location = new System.Drawing.Point(740, 394);
            this.btnClearMdc.Name = "btnClearMdc";
            this.btnClearMdc.Size = new System.Drawing.Size(108, 43);
            this.btnClearMdc.TabIndex = 4152;
            this.btnClearMdc.Text = "Limpar";
            this.btnClearMdc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClearMdc.UseVisualStyleBackColor = true;
            this.btnClearMdc.Click += new System.EventHandler(this.btnClearMdc_Click);
            // 
            // btnClearMmc
            // 
            this.btnClearMmc.FlatAppearance.BorderSize = 2;
            this.btnClearMmc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearMmc.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClearMmc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnClearMmc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClearMmc.Location = new System.Drawing.Point(740, 265);
            this.btnClearMmc.Name = "btnClearMmc";
            this.btnClearMmc.Size = new System.Drawing.Size(108, 43);
            this.btnClearMmc.TabIndex = 4151;
            this.btnClearMmc.Text = "Limpar";
            this.btnClearMmc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClearMmc.UseVisualStyleBackColor = true;
            this.btnClearMmc.Click += new System.EventHandler(this.btnClearMmc_Click);
            // 
            // lblb2
            // 
            this.lblb2.AutoSize = true;
            this.lblb2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblb2.Location = new System.Drawing.Point(393, 372);
            this.lblb2.Name = "lblb2";
            this.lblb2.Size = new System.Drawing.Size(27, 25);
            this.lblb2.TabIndex = 4150;
            this.lblb2.Text = "b:";
            // 
            // lblb1
            // 
            this.lblb1.AutoSize = true;
            this.lblb1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblb1.Location = new System.Drawing.Point(393, 247);
            this.lblb1.Name = "lblb1";
            this.lblb1.Size = new System.Drawing.Size(27, 25);
            this.lblb1.TabIndex = 4149;
            this.lblb1.Text = "b:";
            // 
            // txtboxMdcB
            // 
            this.txtboxMdcB.Location = new System.Drawing.Point(424, 372);
            this.txtboxMdcB.Name = "txtboxMdcB";
            this.txtboxMdcB.Size = new System.Drawing.Size(62, 31);
            this.txtboxMdcB.TabIndex = 4148;
            // 
            // txtboxMmcB
            // 
            this.txtboxMmcB.Location = new System.Drawing.Point(424, 244);
            this.txtboxMmcB.Name = "txtboxMmcB";
            this.txtboxMmcB.Size = new System.Drawing.Size(62, 31);
            this.txtboxMmcB.TabIndex = 4143;
            // 
            // checkboxMdc
            // 
            this.checkboxMdc.AutoSize = true;
            this.checkboxMdc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkboxMdc.Location = new System.Drawing.Point(158, 374);
            this.checkboxMdc.Name = "checkboxMdc";
            this.checkboxMdc.Size = new System.Drawing.Size(73, 29);
            this.checkboxMdc.TabIndex = 4146;
            this.checkboxMdc.Text = "mdc";
            this.checkboxMdc.UseVisualStyleBackColor = true;
            // 
            // checkboxMmc
            // 
            this.checkboxMmc.AutoSize = true;
            this.checkboxMmc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkboxMmc.Location = new System.Drawing.Point(158, 246);
            this.checkboxMmc.Name = "checkboxMmc";
            this.checkboxMmc.Size = new System.Drawing.Size(78, 29);
            this.checkboxMmc.TabIndex = 4141;
            this.checkboxMmc.Text = "mmc";
            this.checkboxMmc.UseVisualStyleBackColor = true;
            // 
            // lbla2
            // 
            this.lbla2.AutoSize = true;
            this.lbla2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbla2.Location = new System.Drawing.Point(271, 372);
            this.lbla2.Name = "lbla2";
            this.lbla2.Size = new System.Drawing.Size(25, 25);
            this.lbla2.TabIndex = 4145;
            this.lbla2.Text = "a:";
            // 
            // lbla1
            // 
            this.lbla1.AutoSize = true;
            this.lbla1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbla1.Location = new System.Drawing.Point(271, 247);
            this.lbla1.Name = "lbla1";
            this.lbla1.Size = new System.Drawing.Size(25, 25);
            this.lbla1.TabIndex = 4144;
            this.lbla1.Text = "a:";
            // 
            // txtboxMdcA
            // 
            this.txtboxMdcA.Location = new System.Drawing.Point(302, 372);
            this.txtboxMdcA.Name = "txtboxMdcA";
            this.txtboxMdcA.Size = new System.Drawing.Size(59, 31);
            this.txtboxMdcA.TabIndex = 4147;
            // 
            // txtboxMmcA
            // 
            this.txtboxMmcA.Location = new System.Drawing.Point(302, 244);
            this.txtboxMmcA.Name = "txtboxMmcA";
            this.txtboxMmcA.Size = new System.Drawing.Size(59, 31);
            this.txtboxMmcA.TabIndex = 4142;
            // 
            // checkboxAlgoritmoEuclides
            // 
            this.checkboxAlgoritmoEuclides.AutoSize = true;
            this.checkboxAlgoritmoEuclides.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkboxAlgoritmoEuclides.Location = new System.Drawing.Point(158, 443);
            this.checkboxAlgoritmoEuclides.Name = "checkboxAlgoritmoEuclides";
            this.checkboxAlgoritmoEuclides.Size = new System.Drawing.Size(216, 29);
            this.checkboxAlgoritmoEuclides.TabIndex = 4146;
            this.checkboxAlgoritmoEuclides.Text = "Algoritimo de euclides";
            this.checkboxAlgoritmoEuclides.UseVisualStyleBackColor = true;
            // 
            // FormMmcMdc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(984, 664);
            this.Controls.Add(this.txtboxAnwserMdc);
            this.Controls.Add(this.lblAnwserMdc);
            this.Controls.Add(this.txtboxAnwserMmc);
            this.Controls.Add(this.lblAnwserMmc);
            this.Controls.Add(this.btnCorrectMdc);
            this.Controls.Add(this.btnCorrectMmc);
            this.Controls.Add(this.btnClearMdc);
            this.Controls.Add(this.btnClearMmc);
            this.Controls.Add(this.lblb2);
            this.Controls.Add(this.lblb1);
            this.Controls.Add(this.txtboxMdcB);
            this.Controls.Add(this.txtboxMmcB);
            this.Controls.Add(this.checkboxAlgoritmoEuclides);
            this.Controls.Add(this.checkboxMdc);
            this.Controls.Add(this.checkboxMmc);
            this.Controls.Add(this.lbla2);
            this.Controls.Add(this.lbla1);
            this.Controls.Add(this.txtboxMdcA);
            this.Controls.Add(this.txtboxMmcA);
            this.Controls.Add(this.panelTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormMmcMdc";
            this.Text = "FormMmcMdc";
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitleMmcMdc;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.TextBox txtboxAnwserMdc;
        private System.Windows.Forms.Label lblAnwserMdc;
        private System.Windows.Forms.TextBox txtboxAnwserMmc;
        private System.Windows.Forms.Label lblAnwserMmc;
        private System.Windows.Forms.Button btnCorrectMdc;
        private System.Windows.Forms.Button btnCorrectMmc;
        private System.Windows.Forms.Button btnClearMdc;
        private System.Windows.Forms.Button btnClearMmc;
        private System.Windows.Forms.Label lblb2;
        private System.Windows.Forms.Label lblb1;
        private System.Windows.Forms.TextBox txtboxMdcB;
        private System.Windows.Forms.TextBox txtboxMmcB;
        private System.Windows.Forms.CheckBox checkboxMdc;
        private System.Windows.Forms.CheckBox checkboxMmc;
        private System.Windows.Forms.Label lbla2;
        private System.Windows.Forms.Label lbla1;
        private System.Windows.Forms.TextBox txtboxMdcA;
        private System.Windows.Forms.TextBox txtboxMmcA;
        private System.Windows.Forms.CheckBox checkboxAlgoritmoEuclides;
    }
}