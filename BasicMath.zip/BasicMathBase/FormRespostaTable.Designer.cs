﻿
namespace BasicMathBase
{
    partial class FormRespostaTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAcerto = new System.Windows.Forms.Label();
            this.btnObterResposta = new System.Windows.Forms.Button();
            this.lblRespostaCorreta = new System.Windows.Forms.Label();
            this.tlbOrdemClase = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_uUnidades = new System.Windows.Forms.Label();
            this.lbl_dUnidades = new System.Windows.Forms.Label();
            this.lbl_cUnidades = new System.Windows.Forms.Label();
            this.lbl_uMilhares = new System.Windows.Forms.Label();
            this.lbl_dMilhares = new System.Windows.Forms.Label();
            this.lbl_cMilhares = new System.Windows.Forms.Label();
            this.lbl_uMilhoes = new System.Windows.Forms.Label();
            this.lbl_dMilhoes = new System.Windows.Forms.Label();
            this.lbl_cMilhoes = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_Milhões = new System.Windows.Forms.Label();
            this.lbl_Milhares = new System.Windows.Forms.Label();
            this.lbl_Unidades = new System.Windows.Forms.Label();
            this.tlbOrdemClase.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAcerto
            // 
            this.lblAcerto.AutoSize = true;
            this.lblAcerto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAcerto.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAcerto.Location = new System.Drawing.Point(364, 71);
            this.lblAcerto.Name = "lblAcerto";
            this.lblAcerto.Size = new System.Drawing.Size(260, 32);
            this.lblAcerto.TabIndex = 0;
            this.lblAcerto.Text = "Resposta Correta!";
            // 
            // btnObterResposta
            // 
            this.btnObterResposta.FlatAppearance.BorderSize = 2;
            this.btnObterResposta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnObterResposta.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnObterResposta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnObterResposta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnObterResposta.Location = new System.Drawing.Point(351, 436);
            this.btnObterResposta.Name = "btnObterResposta";
            this.btnObterResposta.Size = new System.Drawing.Size(280, 65);
            this.btnObterResposta.TabIndex = 5;
            this.btnObterResposta.Text = "Obter Resposta";
            this.btnObterResposta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnObterResposta.UseVisualStyleBackColor = true;
            this.btnObterResposta.Click += new System.EventHandler(this.btnObterResposta_Click);
            // 
            // lblRespostaCorreta
            // 
            this.lblRespostaCorreta.AutoSize = true;
            this.lblRespostaCorreta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRespostaCorreta.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblRespostaCorreta.Location = new System.Drawing.Point(100, 150);
            this.lblRespostaCorreta.Name = "lblRespostaCorreta";
            this.lblRespostaCorreta.Size = new System.Drawing.Size(0, 29);
            this.lblRespostaCorreta.TabIndex = 0;
            // 
            // tlbOrdemClase
            // 
            this.tlbOrdemClase.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tlbOrdemClase.ColumnCount = 11;
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlbOrdemClase.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tlbOrdemClase.Controls.Add(this.label3, 9, 0);
            this.tlbOrdemClase.Controls.Add(this.label4, 8, 0);
            this.tlbOrdemClase.Controls.Add(this.label1, 10, 0);
            this.tlbOrdemClase.Controls.Add(this.label5, 6, 0);
            this.tlbOrdemClase.Controls.Add(this.label6, 5, 0);
            this.tlbOrdemClase.Controls.Add(this.label7, 4, 0);
            this.tlbOrdemClase.Controls.Add(this.label9, 1, 0);
            this.tlbOrdemClase.Controls.Add(this.label10, 0, 0);
            this.tlbOrdemClase.Controls.Add(this.lbl_uUnidades, 10, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_dUnidades, 9, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_cUnidades, 8, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_uMilhares, 6, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_dMilhares, 5, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_cMilhares, 4, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_uMilhoes, 2, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_dMilhoes, 1, 1);
            this.tlbOrdemClase.Controls.Add(this.lbl_cMilhoes, 0, 1);
            this.tlbOrdemClase.Controls.Add(this.label8, 2, 0);
            this.tlbOrdemClase.Location = new System.Drawing.Point(254, 236);
            this.tlbOrdemClase.Name = "tlbOrdemClase";
            this.tlbOrdemClase.RowCount = 2;
            this.tlbOrdemClase.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tlbOrdemClase.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tlbOrdemClase.Size = new System.Drawing.Size(451, 97);
            this.tlbOrdemClase.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(378, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "d";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(339, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "c";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(425, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "u";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(256, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "u";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(214, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "d";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(175, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 25);
            this.label7.TabIndex = 0;
            this.label7.Text = "c";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(50, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 25);
            this.label9.TabIndex = 0;
            this.label9.Text = "d";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(11, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 25);
            this.label10.TabIndex = 0;
            this.label10.Text = "c";
            // 
            // lbl_uUnidades
            // 
            this.lbl_uUnidades.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_uUnidades.AutoSize = true;
            this.lbl_uUnidades.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_uUnidades.Location = new System.Drawing.Point(436, 57);
            this.lbl_uUnidades.Name = "lbl_uUnidades";
            this.lbl_uUnidades.Size = new System.Drawing.Size(0, 25);
            this.lbl_uUnidades.TabIndex = 1;
            // 
            // lbl_dUnidades
            // 
            this.lbl_dUnidades.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_dUnidades.AutoSize = true;
            this.lbl_dUnidades.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_dUnidades.Location = new System.Drawing.Point(390, 57);
            this.lbl_dUnidades.Name = "lbl_dUnidades";
            this.lbl_dUnidades.Size = new System.Drawing.Size(0, 25);
            this.lbl_dUnidades.TabIndex = 2;
            // 
            // lbl_cUnidades
            // 
            this.lbl_cUnidades.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_cUnidades.AutoSize = true;
            this.lbl_cUnidades.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_cUnidades.Location = new System.Drawing.Point(349, 57);
            this.lbl_cUnidades.Name = "lbl_cUnidades";
            this.lbl_cUnidades.Size = new System.Drawing.Size(0, 25);
            this.lbl_cUnidades.TabIndex = 2;
            // 
            // lbl_uMilhares
            // 
            this.lbl_uMilhares.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_uMilhares.AutoSize = true;
            this.lbl_uMilhares.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_uMilhares.Location = new System.Drawing.Point(267, 57);
            this.lbl_uMilhares.Name = "lbl_uMilhares";
            this.lbl_uMilhares.Size = new System.Drawing.Size(0, 25);
            this.lbl_uMilhares.TabIndex = 2;
            // 
            // lbl_dMilhares
            // 
            this.lbl_dMilhares.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_dMilhares.AutoSize = true;
            this.lbl_dMilhares.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_dMilhares.Location = new System.Drawing.Point(226, 57);
            this.lbl_dMilhares.Name = "lbl_dMilhares";
            this.lbl_dMilhares.Size = new System.Drawing.Size(0, 25);
            this.lbl_dMilhares.TabIndex = 2;
            // 
            // lbl_cMilhares
            // 
            this.lbl_cMilhares.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_cMilhares.AutoSize = true;
            this.lbl_cMilhares.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_cMilhares.Location = new System.Drawing.Point(185, 57);
            this.lbl_cMilhares.Name = "lbl_cMilhares";
            this.lbl_cMilhares.Size = new System.Drawing.Size(0, 25);
            this.lbl_cMilhares.TabIndex = 2;
            // 
            // lbl_uMilhoes
            // 
            this.lbl_uMilhoes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_uMilhoes.AutoSize = true;
            this.lbl_uMilhoes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_uMilhoes.Location = new System.Drawing.Point(103, 57);
            this.lbl_uMilhoes.Name = "lbl_uMilhoes";
            this.lbl_uMilhoes.Size = new System.Drawing.Size(0, 25);
            this.lbl_uMilhoes.TabIndex = 2;
            // 
            // lbl_dMilhoes
            // 
            this.lbl_dMilhoes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_dMilhoes.AutoSize = true;
            this.lbl_dMilhoes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_dMilhoes.Location = new System.Drawing.Point(62, 57);
            this.lbl_dMilhoes.Name = "lbl_dMilhoes";
            this.lbl_dMilhoes.Size = new System.Drawing.Size(0, 25);
            this.lbl_dMilhoes.TabIndex = 2;
            // 
            // lbl_cMilhoes
            // 
            this.lbl_cMilhoes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_cMilhoes.AutoSize = true;
            this.lbl_cMilhoes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_cMilhoes.Location = new System.Drawing.Point(21, 57);
            this.lbl_cMilhoes.Name = "lbl_cMilhoes";
            this.lbl_cMilhoes.Size = new System.Drawing.Size(0, 25);
            this.lbl_cMilhoes.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(92, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 25);
            this.label8.TabIndex = 0;
            this.label8.Text = "u";
            // 
            // lbl_Milhões
            // 
            this.lbl_Milhões.AutoSize = true;
            this.lbl_Milhões.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Milhões.Location = new System.Drawing.Point(283, 208);
            this.lbl_Milhões.Name = "lbl_Milhões";
            this.lbl_Milhões.Size = new System.Drawing.Size(74, 25);
            this.lbl_Milhões.TabIndex = 7;
            this.lbl_Milhões.Text = "Milhões";
            // 
            // lbl_Milhares
            // 
            this.lbl_Milhares.AutoSize = true;
            this.lbl_Milhares.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Milhares.Location = new System.Drawing.Point(443, 208);
            this.lbl_Milhares.Name = "lbl_Milhares";
            this.lbl_Milhares.Size = new System.Drawing.Size(78, 25);
            this.lbl_Milhares.TabIndex = 7;
            this.lbl_Milhares.Text = "Milhares";
            // 
            // lbl_Unidades
            // 
            this.lbl_Unidades.AutoSize = true;
            this.lbl_Unidades.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Unidades.Location = new System.Drawing.Point(600, 208);
            this.lbl_Unidades.Name = "lbl_Unidades";
            this.lbl_Unidades.Size = new System.Drawing.Size(86, 25);
            this.lbl_Unidades.TabIndex = 7;
            this.lbl_Unidades.Text = "Unidades";
            // 
            // FormRespostaTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(962, 513);
            this.Controls.Add(this.lbl_Unidades);
            this.Controls.Add(this.lbl_Milhares);
            this.Controls.Add(this.lbl_Milhões);
            this.Controls.Add(this.tlbOrdemClase);
            this.Controls.Add(this.btnObterResposta);
            this.Controls.Add(this.lblAcerto);
            this.Controls.Add(this.lblRespostaCorreta);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FormRespostaTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Correção";
            this.tlbOrdemClase.ResumeLayout(false);
            this.tlbOrdemClase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAcerto;
        private System.Windows.Forms.Button btnObterResposta;
        private System.Windows.Forms.Label lblRespostaCorreta;
        private System.Windows.Forms.TableLayoutPanel tlbOrdemClase;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_uUnidades;
        private System.Windows.Forms.Label lbl_dUnidades;
        private System.Windows.Forms.Label lbl_cUnidades;
        private System.Windows.Forms.Label lbl_uMilhares;
        private System.Windows.Forms.Label lbl_dMilhares;
        private System.Windows.Forms.Label lbl_cMilhares;
        private System.Windows.Forms.Label lbl_uMilhoes;
        private System.Windows.Forms.Label lbl_dMilhoes;
        private System.Windows.Forms.Label lbl_cMilhoes;
        private System.Windows.Forms.Label lbl_Milhões;
        private System.Windows.Forms.Label lbl_Milhares;
        private System.Windows.Forms.Label lbl_Unidades;
    }
}